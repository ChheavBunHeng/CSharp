package Java;
class Main
{
    public static void main(String[] args) {
        public void addTypelist
    }
}