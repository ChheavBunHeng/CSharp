package Java;

public class Frame {

}
