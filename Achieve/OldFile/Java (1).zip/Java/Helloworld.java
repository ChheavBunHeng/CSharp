package Java;

import java.util.Scanner;

public class Helloworld 
{
    public static void main(String[] args)
    {
        String Name = "HEllo world";
        System.out.println(Name);
        Double number= 12.2;
        System.out.println(number);
        

    }

}