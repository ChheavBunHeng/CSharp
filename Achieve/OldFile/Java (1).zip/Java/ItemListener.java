package Java;

public interface ItemListener {

}
