package Java;

import  java.awt.*;
import  java.awt.event.*;

public class HW2 extends Frame implements ItemListener 
{
    Label ID = new Label("ID:");

    @Override
    public void itemStateChanged(ItemEvent arg0) {
        // TODO Auto-generated method stub
        
    }
    ID.setBounds(20,50,100,20);e

    
}
