package Java;

import java.awt.*;
public class Label
{
    public Label(String string) {
    }

    public static void main(String[] args) {
        Frame f = new Frame("Label Example");
        Label l1, l2;

        l1 = new Label("FIrst Label");
        l1.setBounds(50,100,100,30);    
        f.add(l1);

        f.setSize(400,400);
        f.setLayout(null);
        f.setVisible(true);
    }

    public void setBounds(int i, int j, int k, int l) {
    }

    public void setFont(Font labelFont) {
    }

    public void setForeground(Color white) {
    }

}