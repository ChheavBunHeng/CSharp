// Demonstrate check box group. 
import java.awt.*;
import java.awt.event.*;

class MyCBGroup extends Frame implements ItemListener {
  String msg = "";
  Checkbox Win98, winNT, solaris, mac;
  CheckboxGroup cbg;

  MyCBGroup() {
    super("My Checkbox Group Demo");
    setLayout(new FlowLayout()); 
    setSize(320, 220);

    cbg = new CheckboxGroup();
   
    Win98 = new Checkbox("Windows 98", cbg, true);
    winNT = new Checkbox("Windows NT", cbg, false);
    solaris = new Checkbox("Solaris", cbg, false);
    mac = new Checkbox("MacOS", cbg, false);

    add(Win98);
    add(winNT);
    add(solaris);
    add(mac);

    Win98.addItemListener(this);
    winNT.addItemListener(this);
    solaris.addItemListener(this);
    mac.addItemListener(this);
    
    addWindowListener(new WindowAdapter(){
        public void windowClosing(WindowEvent we){
          System.exit(0);
        }
    });       
    setVisible(true);
  }
  public void itemStateChanged(ItemEvent ie) {
    repaint();
  }
  // Display current state of the check boxes.
  public void paint(Graphics g) {
    msg = "Current selection: ";
    msg += cbg.getSelectedCheckbox().getLabel();
    g.drawString(msg, 6, 100);
  }
  public static void main(String args[]){
    new MyCBGroup();
  }
}