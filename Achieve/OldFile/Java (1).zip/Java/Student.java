// package TestEvent;

import java.awt.*;
import java.applet.*;
import java.awt.event.*;
import javax.swing.JTable;

public class Student extends Applet implements ActionListener  {
    String name = "", gender = "";
    int age ,id;
    double salary;
    JTable table = new JTable();
    Object[] colums = {"ID","Name","Gender","Age","Salary"};

    TextField n = new TextField(10);
    TextField d = new TextField(10);
    TextField sex = new TextField(10);
    TextField ages = new TextField(10);
    TextField salarys = new TextField(5); 
   
    Label l = new Label(" Employee\n\n");
    Label l1 = new Label("Enter ID :");
    Label l2 = new Label("Enter Name : ");
    Label l3 = new Label("Enter Gender :");
    Label l4 = new Label("Enter Age :");
    Label l5 = new Label("Enter Salary :");
    Button b1 = new Button("ADD");
    Button b2 = new Button("REMOVE");
    Button b3 = new Button("CLEAR");
    public void init(){
        super.init();
        add(l);
        add(l1);add(d);
        add(l2);add(n);
        add(l3);add(sex);
        add(l4);add(ages);
        add(l5);add(salarys);
        add(b1);
        add(b2);
        add(b3);
        add(table);
    }
    public void actionPerformed(ActionEvent arg0){}

}