package Java.Test;

public class Helo {
    public static void main(String[] args) {
        Helo1 Hello = new Helo1();
        Hello.ASD();
    }
}
