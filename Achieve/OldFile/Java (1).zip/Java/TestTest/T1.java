package Java.TestTest;
import Java.TestTest.*;
public class T1 {
    public static void main(String[] args) {   
        T2 t2 = new T2();
        t2.input1();
    }
}
