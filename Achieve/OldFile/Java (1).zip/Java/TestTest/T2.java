package Java.TestTest;

public class T2 {
    void input1()
    {
        System.out.println("Hellworld");
    }
}
