package Java.TestTest;
// import Java.TestTest.*;

class Jo 
{
    public static void main(String[] args) {
        
        Hello1 H = new Hello1();
        H.input();
    }
}
