package Java.TestTest;

class Hello1
{
    void input()
    {
        System.out.println("Hello world");
    }
}
