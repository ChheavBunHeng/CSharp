
import  java.awt.*;
import  java.awt.event.*;
import  java.awt.event.WindowAdapter;
import  java.awt.event.WindowEvent;

// import Java.Frame;
// import Java.ItemListener;

public class Textfield extends Frame implements ItemListener
{
    Label l1 = New Labal("Hello");
}