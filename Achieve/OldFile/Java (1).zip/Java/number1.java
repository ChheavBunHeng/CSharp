package Java;

public class number1 
{
    public static void main(String[] args)
    {
        int  ID=2;
        String name="ka";
        float Salary=10;
        System.out.println(ID);
        System.out.println(name);
        System.out.println(Salary);


    

    }

}
