

import java.util.Scanner;

public class number2 
{
    public static void main(String[] args)
    {
        int num1;
        int num2;
        float Salary;
        String name;
        char gender;
        Double ID;
        Scanner cin=new Scanner(System.in);
        System.out.println("Input Name");
        name=cin.nextLine();
        System.out.println("Input Num1");
        num1=cin.nextInt();
        System.out.println("Input Num21");
        num2=cin.nextInt();
        System.out.println("Input Salary");
        Salary=cin.nextFloat();
        System.out.println("Input ID");
        ID=cin.nextDouble();
        System.out.println(num1);
        System.out.println(num2);
        System.out.println(Salary);
        System.out.println(name);
        System.out.println(ID);


    }
    
}
