package Java;

import java.util.Scanner;

public class number4 
{
    public static void main(String[] args) 
    {Scanner num=new Scanner(System.in);
    int num1;
    int num2;
    int sum;
    System.out.println("num1");
    num1=num.nextInt();
    System.out.println("num2");
    num2=num.nextInt();
    sum=num1+num2;
    System.out.println(num1);
    System.out.println(num2);
    System.out.println(sum);
    }


    
}
