import java.awt.*;
   import java.awt.event.*;
 
   class MyAddColors extends Frame implements ItemListener 
   {
     Checkbox red, green, blue;
     Canvas canvas;

     MyAddColors() 
     {
       super("My Add Colors");
       setLayout(new FlowLayout()); 
       setSize(400, 380);

       red = new Checkbox("Red");
       red.addItemListener(this);
       add(red);
       green = new Checkbox("Green");
       green.addItemListener(this);
       add(green);
       blue = new Checkbox("Blue");
       blue.addItemListener(this);
       add(blue);
       canvas = new Canvas();
       canvas.setBackground(Color.black);
       canvas.setSize(30, 30);
       add(canvas);
       setVisible(true);
     }  
     public void itemStateChanged(ItemEvent ie) 
     {
       int rgb = 0;
       if(red.getState())
         rgb = 0xff0000;
       if(green.getState())
         rgb |= 0x00ff00;
       if(blue.getState())
         rgb |= 0x0000ff;
       Color color = new Color(rgb);
       canvas.setBackground(color);
       canvas.repaint();
     }
     public static void main(String args[]){
        new MyAddColors();
     }
   }